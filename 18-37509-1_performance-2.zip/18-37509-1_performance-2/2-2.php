<?php  
 $amount = 5000;  
 $vat;  
 echo "VAT" . ($vat=0.15*$amount) . "<br />"; 
 
  ?> 