<?
php
for($i=10;$i<100;)
{
echo $i;
$i=$i+2;
}
?>