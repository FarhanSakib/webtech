<html>
<body>

<form action="welcome.php" method="post">
Blood Group<br>
<select name="bgs">
  <option value="A+">A+</option>
  <option value="B+">B+</option>
  <option value="AB+">AB+</option>
  <option value="O+">O+</option>
   <option value="A-">A-</option>
    <option value="B-">B-</option>
  

</select><br>
<input type="submit">
</form>

</body>
</html>