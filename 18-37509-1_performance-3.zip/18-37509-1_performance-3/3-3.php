<html>
<body>

<form action="welcome.php" method="post">
Date of Birth<br>
<input type="date" name="date" value="dd /">
<input type="date" name="date" value="mm /">
<input type="date" name="date" value="year /"><br>
<input type="submit">
</form>

</body>
</html>