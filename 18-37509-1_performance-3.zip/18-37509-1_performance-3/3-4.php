<html>
<body>

<form action="welcome.php" method="post">
	Gender<br>
  <input type="radio" name="gender" value="male"> Male
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="other"> Other<br>
  <input type="submit">
</form>
</body>
</html>